# STAR VOYAGER — 開発引継ぎメモ

更新：2026-11-07 / 対象：M5Stack StopWatch / 開発版：R16 FIX8

## 現状と実機実績

- R16 FIX4（M5Unified/M5GFX 0.3.0、`BOARD_ID=30`）はユーザー実機で画面表示成功。
- R16 FIX5以降の入力・大気リム・推力・ワープ修正は段階的なホストテスト済みだが、FIX8の実機合格は未確認。
- R16 FIX6：最大加速度240,000m/s²、押下解放後約1.1秒のスラスター余韻。
- R16 FIX7：惑星・月・Voyager到着時の座標、機首方向、相対速度を合わせ、到着光を1.8秒で消去。航行画面のターゲットマーカーと名称は不要。
- R16 FIX8：FIX7で「ワープ演出が見えなくなった」との報告に対応。旧リング・星の流線・フラッシュを保持し、描画済みフレームに応じてワープ経過を進める。ワープ中は球面描画を省略し、演出の視認性を優先。終了後の天体表示と到着余韻はそのまま。

## 最重要：StopWatch共通開発規約R1（1〜13章）を優先

- M5Unified **0.3.0** / M5GFX **0.3.0** を対で使用。StopWatch `BOARD_ID=30`。
- 画面表示成功時の`M5.begin(cfg)`単一起動と最初の直接描画を保護。AMOLED電源/リセットの独自制御・GPIO46操作は禁止。
- 入力は`M5.update()`とBtnA/BtnB、M5.Touch API。二重イベントに注意。
- PSRAMスプライトの非同期DMA利用時は必要箇所で転送完了待機。
- ESP32-S3R8、16MB Flash、8MB PSRAM。不要なバックアップや診断専用ランを挟まない。

## 重大な過去トラブル：APP書込先の誤り

実機ログに基づく構成：`ota_0` = `0x20000` / size `0x4F0000`、`ota_1` = `0x510000` / size `0x4F0000`、`otadata` = `0xD000`。旧版は誤って`0x10000`へ書き込み、ブートローダーがアプリを見つけられず画面が出なかった。**画面ドライバの不良とは別問題**。

書込CMDは実機パーティション表と`otadata`の起動先を必ず読み取り専用で照合。次回起動が`ota_0`でない場合や構成不一致の場合は書き込まず終了。通常更新でパーティション/otadata/NVS/Storage/Coredumpを変更しない。

## ソース構成

- `firmware/src/main.cpp`：画面、入力、描画、航行、ワープFX。
- `firmware/include/astro.hpp`：天体計算、重力、宇宙船状態。
- `firmware/include/warp_arrival.hpp`：対象への安全な到着位置・視線・相対速度。
- `firmware/include/warp_timing.hpp`：R16 FIX8のフレーム同期ワープタイミング。
- `firmware/include/fast_sphere.hpp` / `firmware/src/fast_sphere_lut.cpp`：球面UVテーブル。
- `firmware/include/planet_textures.hpp`：RGB565天体テクスチャ。
- `tests/` / `firmware/test/`：ホストテスト。
- `tools/verify_ota0.py`：書込前のパーティション・起動先照合。

## 次の合格条件

実機で1）表示、2）左右ボタン、3）ワープ中のリング/流線/フラッシュ表示、4）到着先天体・Voyagerの視認、5）1.8秒で到着余韻が消えることを確認。ホストテストPASSを実機合格とは呼ばない。

## 配布・権利

ソースコードはMIT（`LICENSE`）。第三者ライブラリと素材の権利は別途適用（`THIRD_PARTY_NOTICES.md`）。
