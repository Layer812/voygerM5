#pragma once
#include <cstdlib>
#define MALLOC_CAP_SPIRAM 1024
#define MALLOC_CAP_8BIT 8
inline void* heap_caps_malloc(size_t n,int){return std::malloc(n);}
