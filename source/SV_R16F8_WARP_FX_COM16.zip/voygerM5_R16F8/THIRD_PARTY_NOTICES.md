# Third-party components and asset notices

The MIT license in `LICENSE` is offered for the original STAR VOYAGER source code written for this project; it **does not override** the licenses or usage terms of third-party materials and libraries.

- **M5Unified / M5GFX / M5PM1 / M5IOE1:** independently developed M5Stack libraries; follow the licenses in their upstream repositories. They are dependencies, not vendored here.
- **Planetary orbital approximations:** based on public JPL approximate planetary positions; gameplay models are approximate and not a navigation ephemeris.
- **Earth and other planetary texture data:** embedded RGB565 arrays in `firmware/include/planet_textures.hpp` were included in earlier project versions. The project has used NASA Blue Marble material and generated placeholder textures. Source attribution for every embedded planet texture has *not* been independently verified in this release. Do not assume the MIT software license governs these texture assets or represents an endorsement by NASA/JPL.
- **Tutorial UI artwork:** project-specific artwork included as RGB565/JPEG-derived data; no trademark endorsement is implied.

If preparing a public distribution, verify provenance and permitted redistribution for every embedded texture and image. When uncertain, replace it with self-created or clearly licensed imagery before release.
