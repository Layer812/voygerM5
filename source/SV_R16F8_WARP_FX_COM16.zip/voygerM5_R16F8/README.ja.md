# STAR VOYAGER — M5Stack StopWatch

M5Stack StopWatch向けの宇宙航行シミュレータです。重力・姿勢制御スラスター・ワープで惑星、月、Voyager 1/2の周辺を飛行できます。

## 操作

- **画面中央をスワイプ：** RCSによる機首姿勢の変更
- **下側の外周をスワイプ：** スロットル（左＝逆噴射、6時＝中立、右＝前進）
- **右ボタン長押し：** 主スラスター噴射
- **左ボタン：** ワープ先メニュー。スワイプで選択、右ボタンで決定
- **中央長押し：** HUD表示切替

## ビルド・書き込み

Windows + PlatformIO。ESP32-S3R8 / Flash 16MB / PSRAM 8MB、`BOARD_ID=30`。M5UnifiedとM5GFXは**両方とも0.3.0**。

- ビルドのみ：`BUILD_R16F8_NO_FLASH.cmd`
- COM16へAPPのみ：`RUN_R16F8_BUILD_FLASH_APP_ONLY_COM16.cmd`

書込CMDは、実機のパーティション表とOTA起動先を読み取り専用で照合します。確認済みの機体では`ota_0`（`0x20000`）にのみ書き込みます。**`0x10000`等の一般的なアドレスを使用しません。** ブートローダー、パーティション表、NVS、otadata、Storageなどは変更しません。

**開発状態：** R16 FIX8ソース候補。ホストテストPASS。FIX8は実機ビルド・表示・操作が未確認です。FIX4では実機画面表示の報告があります。

[English](README.md) · [開発引継ぎ](HANDOFF.ja.md) · [ライセンス](LICENSE) · [画像等の出典](THIRD_PARTY_NOTICES.md)
