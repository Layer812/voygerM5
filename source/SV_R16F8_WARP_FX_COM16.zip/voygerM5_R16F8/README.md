# STAR VOYAGER — M5Stack StopWatch

Spaceflight simulator for the M5Stack StopWatch (ESP32-S3). Explore planets, the Moon, and Voyager 1/2 with gravity, thrusters, warp travel, and a real-Earth-style display.

## Controls

- **Swipe center:** change spacecraft attitude (RCS).
- **Swipe lower outer rim:** throttle; left = reverse, 6 o’clock = neutral, right = forward.
- **Hold right button:** main engine thrust.
- **Press left button:** warp destination menu; swipe to select, right button to warp.
- **Long-press center:** show/hide HUD.

## Build and install

Requires PlatformIO on Windows. Hardware: ESP32-S3R8, 16 MB Flash, 8 MB PSRAM, StopWatch `BOARD_ID=30`.

- Libraries: **M5Unified 0.3.0 / M5GFX 0.3.0** (paired).
- Build only: `BUILD_R16F8_NO_FLASH.cmd`.
- COM16, APP-only: `RUN_R16F8_BUILD_FLASH_APP_ONLY_COM16.cmd`.

The flash script checks the *actual* partition layout and OTA boot slot before writing. On the currently tested device it writes only `ota_0` at `0x20000`. **Never use a generic `0x10000` app offset.** It does not erase the whole flash or overwrite the bootloader, partition table, NVS, `otadata`, or storage. If the device differs, the script refuses to flash.

**Release:** R16 FIX8 source candidate. Host tests PASS; Windows PlatformIO and device behavior for FIX8 are **not yet verified**. The preceding FIX4 hardware display was reported working.

[日本語README](README.ja.md) · [Development handoff (日本語)](HANDOFF.ja.md) · [License](LICENSE) · [Asset notices](THIRD_PARTY_NOTICES.md)
